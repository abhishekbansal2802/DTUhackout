lang = "en"
full_language = "english"


def change_lang(lang_p, language_p):
    global lang
    lang = lang_p
    global full_language
    full_language = language_p
